/** @type {import('tailwindcss').Config} */
export default {
  content: [],
  theme: {
    extend: {},
  },
  plugins: [],
}

// tailwind.config.js

module.exports = {
  theme: {
    extend: {
      fontFamily: {
        techno: ['Techno Hideo', 'sans-serif'],      },
    },
  },
  // Other Tailwind CSS configurations...
};
